import { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Check, X, Wrench, MessageSquare } from 'lucide-react'
import type { Block, MarkType } from '@/types/editor'

const SPEAKER_STYLE: Record<string, string> = {
  '凯·默瑟': 'bg-[#2e4a6b] text-white',
  裘德: 'bg-[#3d6b52] text-white',
  叙述: 'bg-[#8b8578] text-white',
}

interface Props {
  block: Block
  onMark: (mark: MarkType) => void
  onNote: (note: string) => void
}

export function BlockCard({ block, onMark, onNote }: Props) {
  const [noteOpen, setNoteOpen] = useState(false)
  const isDeleted = block.mark === 'delete'
  const isRevise = block.mark === 'revise'

  return (
    <article
      className={cn(
        'rounded-lg border bg-white transition-all',
        isDeleted && 'border-[#e0c4bf] opacity-60',
        isRevise && 'border-amber-300 bg-amber-50/40',
        !isDeleted && !isRevise && 'border-[#e8e2d9]'
      )}
    >
      <div className="flex items-center gap-2 px-3 pt-2.5 pb-1.5">
        <span
          className={cn(
            'text-xs font-sans px-2 py-0.5 rounded-full',
            SPEAKER_STYLE[block.speaker] ?? 'bg-[#6b5a8e] text-white'
          )}
        >
          {block.speaker}
        </span>
        <span className="text-[11px] text-[#9a917f] font-sans">{block.content.length} 字</span>
        <div className="flex-1" />
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            title="保留"
            className={cn('h-7 w-7 p-0', block.mark === 'keep' && 'bg-[#e6efe6] text-green-800')}
            onClick={() => onMark('keep')}
          >
            <Check className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            title="待修"
            className={cn('h-7 w-7 p-0', isRevise && 'bg-amber-100 text-amber-700')}
            onClick={() => onMark('revise')}
          >
            <Wrench className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            title="删除"
            className={cn('h-7 w-7 p-0', isDeleted && 'bg-[#f3e0dd] text-[#a33]')}
            onClick={() => onMark('delete')}
          >
            <X className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            title="批注"
            className={cn(
              'h-7 w-7 p-0 relative',
              (block.note || noteOpen) && 'text-[#2e4a6b]'
            )}
            onClick={() => setNoteOpen((v) => !v)}
          >
            <MessageSquare className="w-4 h-4" />
            {block.note && (
              <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-[#2e4a6b]" />
            )}
          </Button>
        </div>
      </div>

      <div
        className={cn(
          'px-4 pb-3 font-serif text-[15px] leading-relaxed text-[#2c2418]',
          isDeleted && 'line-through decoration-[#c25b4e]/60'
        )}
      >
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          components={{
            p: ({ children }) => <p className="my-2">{children}</p>,
            em: ({ children }) => <em className="text-[#4a4032]">{children}</em>,
          }}
        >
          {block.content}
        </ReactMarkdown>
      </div>

      {(noteOpen || block.note) && (
        <div className="px-3 pb-3">
          <Textarea
            value={block.note}
            onChange={(e) => onNote(e.target.value)}
            placeholder="批注：为什么删/待修，或修改思路……"
            className="text-sm font-sans bg-[#fdfcf9] min-h-[60px]"
          />
        </div>
      )}
    </article>
  )
}
