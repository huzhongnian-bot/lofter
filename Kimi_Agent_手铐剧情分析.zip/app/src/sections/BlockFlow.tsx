import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { BlockCard } from './BlockCard'
import { chapterStats } from '@/lib/parser'
import { Check, ChevronDown, ChevronUp, X } from 'lucide-react'
import type { Chapter, MarkType } from '@/types/editor'

interface Props {
  chapter: Chapter | null
  onMark: (chapterId: string, blockId: string, mark: MarkType) => void
  onNote: (chapterId: string, blockId: string, note: string) => void
  onMarkAll: (chapterId: string, mark: MarkType) => void
}

export function BlockFlow({ chapter, onMark, onNote, onMarkAll }: Props) {
  const [showDeleted, setShowDeleted] = useState(true)

  if (!chapter) {
    return (
      <div className="flex-1 flex items-center justify-center text-[#9a917f] font-serif">
        从左侧选择一章开始手术
      </div>
    )
  }

  const s = chapterStats(chapter)
  const visible = chapter.blocks.filter((b) => showDeleted || b.mark !== 'delete')

  return (
    <div className="flex-1 flex flex-col min-w-0">
      <div className="flex items-center gap-3 px-5 py-3 border-b border-[#e8e2d9] bg-[#fdfcf9]">
        <h2 className="font-serif font-bold text-[#2c2418]">{chapter.title}</h2>
        <span className="text-xs font-sans text-[#9a917f]">
          {s.total} 块 · {Math.round(s.totalChars / 100) / 10}k 字
        </span>
        {s.del > 0 && (
          <span className="text-xs font-sans text-[#a33]">
            已删 {s.del} 块 / -{Math.round(s.deletedChars / 100) / 10}k 字
          </span>
        )}
        {s.revise > 0 && (
          <span className="text-xs font-sans text-amber-600">待修 {s.revise} 块</span>
        )}
        <div className="flex-1" />
        <Button
          variant="ghost"
          size="sm"
          className="text-xs"
          onClick={() => onMarkAll(chapter.id, 'keep')}
          title="整章重置为保留"
        >
          <Check className="w-3.5 h-3.5 mr-1" />
          全保留
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="text-xs"
          onClick={() => onMarkAll(chapter.id, 'delete')}
          title="整章标记删除（慎用）"
        >
          <X className="w-3.5 h-3.5 mr-1" />
          全删
        </Button>
        <Button variant="ghost" size="sm" className="text-xs" onClick={() => setShowDeleted((v) => !v)}>
          {showDeleted ? <ChevronUp className="w-3.5 h-3.5 mr-1" /> : <ChevronDown className="w-3.5 h-3.5 mr-1" />}
          {showDeleted ? '隐藏已删' : '显示已删'}
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
        {visible.map((b) => (
          <BlockCard
            key={b.id}
            block={b}
            onMark={(mark) => onMark(chapter.id, b.id, mark)}
            onNote={(note) => onNote(chapter.id, b.id, note)}
          />
        ))}
        {visible.length === 0 && (
          <div className="text-center text-sm text-[#9a917f] font-sans py-10">
            本章没有可显示的块
          </div>
        )}
      </div>
    </div>
  )
}
