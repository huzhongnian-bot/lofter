import { useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import {
  BookOpen,
  FolderOpen,
  FileArchive,
  FileDown,
  FileJson,
  Trash2,
  Scissors,
} from 'lucide-react'
import type { Project } from '@/types/editor'

interface Props {
  project: Project | null
  onImportBook: (file: File) => void
  onImportProject: (file: File) => void
  onImportArchives: (files: FileList) => void
  onExportRevised: () => void
  onExportJson: () => void
  onClear: () => void
}

export function Toolbar({
  project,
  onImportBook,
  onImportProject,
  onImportArchives,
  onExportRevised,
  onExportJson,
  onClear,
}: Props) {
  const bookRef = useRef<HTMLInputElement>(null)
  const projRef = useRef<HTMLInputElement>(null)
  const archRef = useRef<HTMLInputElement>(null)

  return (
    <header className="flex items-center gap-2 px-4 h-14 border-b border-[#e8e2d9] bg-[#fdfcf9] shrink-0">
      <Scissors className="w-5 h-5 text-[#8b6f4e]" />
      <h1 className="font-serif font-bold text-lg text-[#2c2418] whitespace-nowrap">
        {project ? project.bookTitle : '手铐 · 二创编辑台'}
      </h1>
      {project && (
        <span className="text-xs text-[#8b8578] font-sans hidden sm:inline">
          {project.chapters.length} 章 · 自动暂存于本浏览器
        </span>
      )}

      <div className="flex-1" />

      <Button variant="outline" size="sm" onClick={() => bookRef.current?.click()}>
        <BookOpen className="w-4 h-4 mr-1" />
        导入全文
      </Button>
      <Button variant="outline" size="sm" onClick={() => projRef.current?.click()}>
        <FolderOpen className="w-4 h-4 mr-1" />
        打开方案
      </Button>
      {project && (
        <>
          <Button variant="outline" size="sm" onClick={() => archRef.current?.click()}>
            <FileArchive className="w-4 h-4 mr-1" />
            导入档案
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="outline" size="sm" onClick={onExportRevised}>
            <FileDown className="w-4 h-4 mr-1" />
            导出修订版
          </Button>
          <Button variant="outline" size="sm" onClick={onExportJson}>
            <FileJson className="w-4 h-4 mr-1" />
            导出方案
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-[#a33] hover:text-[#a33]"
            onClick={() => {
              if (window.confirm('清空当前项目与浏览器暂存？（已导出的文件不受影响）')) onClear()
            }}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </>
      )}

      <input
        ref={bookRef}
        type="file"
        accept=".md,.txt"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0]
          if (f) onImportBook(f)
          e.target.value = ''
        }}
      />
      <input
        ref={projRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0]
          if (f) onImportProject(f)
          e.target.value = ''
        }}
      />
      <input
        ref={archRef}
        type="file"
        accept=".md,.txt"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) onImportArchives(e.target.files)
          e.target.value = ''
        }}
      />
    </header>
  )
}
