import { cn } from '@/lib/utils'
import { chapterStats } from '@/lib/parser'
import type { Chapter } from '@/types/editor'
import { CheckCircle2, FileArchive } from 'lucide-react'

interface Props {
  chapters: Chapter[]
  activeId: string | null
  archives: Record<string, string>
  onSelect: (id: string) => void
}

export function ChapterTree({ chapters, activeId, archives, onSelect }: Props) {
  return (
    <nav className="w-56 shrink-0 border-r border-[#e8e2d9] bg-[#f7f4ee] overflow-y-auto">
      <div className="px-3 py-2 text-xs font-sans text-[#8b8578]">章节</div>
      <ul>
        {chapters.map((ch) => {
          const s = chapterStats(ch)
          const done = s.total > 0 && s.keep + s.del + s.revise === s.total && (s.del + s.revise) > 0
          const delRate = s.totalChars ? Math.round((s.deletedChars / s.totalChars) * 100) : 0
          return (
            <li key={ch.id}>
              <button
                onClick={() => onSelect(ch.id)}
                className={cn(
                  'w-full text-left px-3 py-2.5 text-sm transition-colors border-l-2',
                  activeId === ch.id
                    ? 'bg-[#efe9dd] border-[#8b6f4e] text-[#2c2418]'
                    : 'border-transparent text-[#5c5546] hover:bg-[#f0ebe1]'
                )}
              >
                <div className="flex items-center gap-1.5">
                  <span className="font-serif font-medium truncate">{ch.title}</span>
                  {archives[ch.id] && (
                    <FileArchive className="w-3.5 h-3.5 text-[#8b6f4e] shrink-0" />
                  )}
                  {done && <CheckCircle2 className="w-3.5 h-3.5 text-green-700 shrink-0" />}
                </div>
                <div className="mt-1 flex items-center gap-2 text-[11px] font-sans text-[#9a917f]">
                  <span>{s.total} 块</span>
                  {delRate > 0 && <span className="text-[#a33]">删 {delRate}%</span>}
                </div>
                {s.total > 0 && (
                  <div className="mt-1.5 h-1 rounded-full bg-[#e3dccf] overflow-hidden flex">
                    <div
                      className="bg-[#b8a684]"
                      style={{ width: `${(s.keep / s.total) * 100}%` }}
                    />
                    <div
                      className="bg-amber-500"
                      style={{ width: `${(s.revise / s.total) * 100}%` }}
                    />
                    <div
                      className="bg-[#c25b4e]"
                      style={{ width: `${(s.del / s.total) * 100}%` }}
                    />
                  </div>
                )}
              </button>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
