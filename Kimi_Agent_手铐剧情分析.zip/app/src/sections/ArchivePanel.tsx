import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { FileArchive, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface Props {
  chapterTitle: string | null
  archive: string | null
  onClose: () => void
}

export function ArchivePanel({ chapterTitle, archive, onClose }: Props) {
  return (
    <aside className="w-[380px] shrink-0 border-l border-[#e8e2d9] bg-[#f7f4ee] flex flex-col">
      <div className="flex items-center gap-2 px-4 h-11 border-b border-[#e8e2d9] shrink-0">
        <FileArchive className="w-4 h-4 text-[#8b6f4e]" />
        <span className="text-sm font-sans font-medium text-[#2c2418]">
          {chapterTitle ? `${chapterTitle} · 档案` : '档案对照'}
        </span>
        <div className="flex-1" />
        <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-3">
        {archive ? (
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              h1: ({ children }) => (
                <h1 className="font-serif font-bold text-base text-[#2c2418] mt-3 mb-2">{children}</h1>
              ),
              h2: ({ children }) => (
                <h2 className="font-serif font-bold text-sm text-[#8b6f4e] mt-4 mb-1.5 border-b border-[#e8e2d9] pb-1">
                  {children}
                </h2>
              ),
              p: ({ children }) => <p className="my-1.5 text-[13px] leading-relaxed text-[#4a4032]">{children}</p>,
              li: ({ children }) => (
                <li className="my-1 text-[13px] leading-relaxed text-[#4a4032] list-disc ml-4">{children}</li>
              ),
              ol: ({ children }) => <ol className="my-1.5">{children}</ol>,
              ul: ({ children }) => <ul className="my-1.5">{children}</ul>,
              strong: ({ children }) => <strong className="text-[#2c2418]">{children}</strong>,
              code: ({ children }) => (
                <code className="text-xs bg-[#efe9dd] px-1 py-0.5 rounded">{children}</code>
              ),
            }}
          >
            {archive}
          </ReactMarkdown>
        ) : (
          <div className="text-sm text-[#9a917f] font-sans mt-8 text-center leading-relaxed">
            本章还没有档案。
            <br />
            点顶部「导入档案」载入
            <br />
            第XX章_档案.md
          </div>
        )}
      </div>
    </aside>
  )
}
