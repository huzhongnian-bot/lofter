import { useRef } from 'react'
import { Button } from '@/components/ui/button'
import { BookOpen, FolderOpen, NotebookPen } from 'lucide-react'

interface Props {
  onImportBook: (file: File) => void
  onImportProject: (file: File) => void
}

export function EmptyState({ onImportBook, onImportProject }: Props) {
  const bookRef = useRef<HTMLInputElement>(null)
  const projRef = useRef<HTMLInputElement>(null)

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6">
      <NotebookPen className="w-12 h-12 text-[#8b6f4e] mb-6" />
      <h2 className="font-serif font-bold text-3xl text-[#2c2418] mb-3">手铐 · 二创编辑台</h2>
      <p className="text-[#8b8578] font-sans text-sm max-w-md text-center leading-relaxed mb-8">
        给跑团实录做手术的工作台：导入全文，按章切块，
        逐块标记保留 / 待修 / 删除，附上批注，
        最后导出修订版与编辑方案。
        <br />
        所有数据只留在你的浏览器与本机文件里。
      </p>
      <div className="flex gap-3">
        <Button size="lg" onClick={() => bookRef.current?.click()}>
          <BookOpen className="w-4 h-4 mr-2" />
          导入《手铐》全文
        </Button>
        <Button variant="outline" size="lg" onClick={() => projRef.current?.click()}>
          <FolderOpen className="w-4 h-4 mr-2" />
          打开已有方案
        </Button>
      </div>
      <p className="mt-6 text-xs text-[#b0a894] font-sans">
        提示：删除的块只是划掉，不会真丢——随时反悔。
      </p>

      <input
        ref={bookRef}
        type="file"
        accept=".md,.txt"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0]
          if (f) onImportBook(f)
          e.target.value = ''
        }}
      />
      <input
        ref={projRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0]
          if (f) onImportProject(f)
          e.target.value = ''
        }}
      />
    </div>
  )
}
