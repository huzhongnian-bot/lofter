import { useMemo, useState } from 'react'
import { Toolbar } from '@/sections/Toolbar'
import { ChapterTree } from '@/sections/ChapterTree'
import { BlockFlow } from '@/sections/BlockFlow'
import { ArchivePanel } from '@/sections/ArchivePanel'
import { EmptyState } from '@/sections/EmptyState'
import { useEditorProject } from '@/hooks/useEditorProject'
import {
  parseBook,
  archiveChapterIndex,
  exportRevised,
  exportProjectJson,
  importProjectJson,
  downloadFile,
} from '@/lib/parser'
import { Button } from '@/components/ui/button'
import { FileArchive } from 'lucide-react'

function readText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result ?? ''))
    r.onerror = reject
    r.readAsText(file)
  })
}

export default function App() {
  const {
    project,
    setProject,
    setMark,
    setNote,
    markAllInChapter,
    setArchive,
    clearProject,
  } = useEditorProject()

  const [activeChapterId, setActiveChapterId] = useState<string | null>(null)
  const [archiveOpen, setArchiveOpen] = useState(true)

  const activeChapter = useMemo(
    () => project?.chapters.find((c) => c.id === activeChapterId) ?? project?.chapters[0] ?? null,
    [project, activeChapterId]
  )

  const handleImportBook = async (file: File) => {
    if (project && !window.confirm('导入全文将替换当前项目（未导出的标记会丢失），继续？')) return
    const text = await readText(file)
    const p = parseBook(text)
    setProject(p)
    setActiveChapterId(p.chapters[0]?.id ?? null)
  }

  const handleImportProject = async (file: File) => {
    const text = await readText(file)
    const p = importProjectJson(text)
    if (!p) {
      window.alert('方案文件无法识别。')
      return
    }
    setProject(p)
    setActiveChapterId(p.chapters[0]?.id ?? null)
  }

  const handleImportArchives = async (files: FileList) => {
    if (!project) return
    let matched = 0
    let missed: string[] = []
    for (const file of Array.from(files)) {
      const idx = archiveChapterIndex(file.name)
      const ch = idx != null ? project.chapters.find((c) => c.index === idx) : null
      if (ch) {
        setArchive(ch.id, await readText(file))
        matched++
      } else {
        missed.push(file.name)
      }
    }
    if (missed.length) {
      window.alert(`已匹配 ${matched} 份档案；以下文件未匹配到章节：\n${missed.join('\n')}`)
    }
  }

  const handleExportRevised = () => {
    if (!project) return
    downloadFile(`${project.bookTitle}_修订版.md`, exportRevised(project), 'text/markdown')
  }

  const handleExportJson = () => {
    if (!project) return
    downloadFile(`${project.bookTitle}_编辑方案.json`, exportProjectJson(project), 'application/json')
  }

  return (
    <div className="h-screen flex flex-col bg-[#f3efe7]">
      <Toolbar
        project={project}
        onImportBook={handleImportBook}
        onImportProject={handleImportProject}
        onImportArchives={handleImportArchives}
        onExportRevised={handleExportRevised}
        onExportJson={handleExportJson}
        onClear={clearProject}
      />

      {!project ? (
        <EmptyState onImportBook={handleImportBook} onImportProject={handleImportProject} />
      ) : (
        <div className="flex-1 flex min-h-0 relative">
          <ChapterTree
            chapters={project.chapters}
            activeId={activeChapter?.id ?? null}
            archives={project.archives}
            onSelect={setActiveChapterId}
          />
          <BlockFlow
            chapter={activeChapter}
            onMark={setMark}
            onNote={setNote}
            onMarkAll={markAllInChapter}
          />
          {archiveOpen ? (
            <ArchivePanel
              chapterTitle={activeChapter?.title ?? null}
              archive={activeChapter ? project.archives[activeChapter.id] ?? null : null}
              onClose={() => setArchiveOpen(false)}
            />
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="absolute right-3 top-3 z-10 bg-white"
              onClick={() => setArchiveOpen(true)}
              title="打开档案对照"
            >
              <FileArchive className="w-4 h-4" />
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
