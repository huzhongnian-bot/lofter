import { useCallback, useEffect, useRef, useState } from 'react'
import type { MarkType, Project } from '@/types/editor'
import { importProjectJson } from '@/lib/parser'

const STORAGE_KEY = 'shoukao-editor-project-v1'

function loadStored(): Project | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    return importProjectJson(raw)
  } catch {
    return null
  }
}

export function useEditorProject() {
  const [project, setProject] = useState<Project | null>(() => loadStored())
  const saveTimer = useRef<number | null>(null)

  // 防抖自动保存到 localStorage
  useEffect(() => {
    if (!project) return
    if (saveTimer.current) window.clearTimeout(saveTimer.current)
    saveTimer.current = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(project))
      } catch {
        // 存储超限时静默失败，用户仍可通过导出 JSON 保存
      }
    }, 600)
    return () => {
      if (saveTimer.current) window.clearTimeout(saveTimer.current)
    }
  }, [project])

  const setMark = useCallback((chapterId: string, blockId: string, mark: MarkType) => {
    setProject((p) => {
      if (!p) return p
      return {
        ...p,
        updatedAt: Date.now(),
        chapters: p.chapters.map((ch) =>
          ch.id !== chapterId
            ? ch
            : {
                ...ch,
                blocks: ch.blocks.map((b) => (b.id === blockId ? { ...b, mark } : b)),
              }
        ),
      }
    })
  }, [])

  const setNote = useCallback((chapterId: string, blockId: string, note: string) => {
    setProject((p) => {
      if (!p) return p
      return {
        ...p,
        updatedAt: Date.now(),
        chapters: p.chapters.map((ch) =>
          ch.id !== chapterId
            ? ch
            : {
                ...ch,
                blocks: ch.blocks.map((b) => (b.id === blockId ? { ...b, note } : b)),
              }
        ),
      }
    })
  }, [])

  /** 整章批量标记 */
  const markAllInChapter = useCallback((chapterId: string, mark: MarkType) => {
    setProject((p) => {
      if (!p) return p
      return {
        ...p,
        updatedAt: Date.now(),
        chapters: p.chapters.map((ch) =>
          ch.id !== chapterId
            ? ch
            : { ...ch, blocks: ch.blocks.map((b) => ({ ...b, mark })) }
        ),
      }
    })
  }, [])

  const setArchive = useCallback((chapterId: string, md: string) => {
    setProject((p) => (p ? { ...p, archives: { ...p.archives, [chapterId]: md } } : p))
  }, [])

  const clearProject = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY)
    setProject(null)
  }, [])

  return { project, setProject, setMark, setNote, markAllInChapter, setArchive, clearProject }
}
