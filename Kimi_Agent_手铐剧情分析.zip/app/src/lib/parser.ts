import type { Chapter, Project, ChapterStats } from '@/types/editor'

let uid = 0
const nextId = () => `b${Date.now()}_${uid++}`

/** 解析《手铐》全文 markdown：按章切分，章内按说话人切块 */
export function parseBook(md: string): Project {
  const lines = md.replace(/^﻿/, '').split(/\r?\n/)

  let bookTitle = '未命名'
  let bookIntro = ''
  const chapters: Chapter[] = []
  let current: Chapter | null = null
  let blockBuf: { speaker: string; lines: string[] } | null = null

  const flushBlock = () => {
    if (!current || !blockBuf) return
    const content = blockBuf.lines.join('\n').trim()
    if (content || blockBuf.speaker !== '叙述') {
      current.blocks.push({
        id: nextId(),
        speaker: blockBuf.speaker,
        content,
        mark: 'keep',
        note: '',
      })
    }
    blockBuf = null
  }

  for (const raw of lines) {
    const line = raw
    const chapterMatch = line.match(/^##\s+(.+)$/)
    const speakerMatch = line.match(/^\*\*(.+?)\*\*\s*$/)

    if (line.startsWith('# ') && !chapterMatch && chapters.length === 0 && !current) {
      bookTitle = line.replace(/^#\s+/, '').trim()
      continue
    }

    if (chapterMatch) {
      flushBlock()
      const title = chapterMatch[1].trim()
      const idxMatch = title.match(/第\s*(\d+)\s*章/)
      current = {
        id: `ch_${idxMatch ? idxMatch[1] : chapters.length + 1}`,
        index: idxMatch ? parseInt(idxMatch[1], 10) : chapters.length + 1,
        title,
        blocks: [],
      }
      chapters.push(current)
      continue
    }

    if (line.startsWith('>') && !current) {
      bookIntro += (bookIntro ? '\n' : '') + line.replace(/^>\s*/, '').trim()
      continue
    }

    if (!current) continue

    if (speakerMatch) {
      flushBlock()
      blockBuf = { speaker: speakerMatch[1].trim(), lines: [] }
      continue
    }

    if (!blockBuf) blockBuf = { speaker: '叙述', lines: [] }
    blockBuf.lines.push(line)
  }
  flushBlock()

  return { bookTitle, bookIntro, chapters, archives: {}, updatedAt: Date.now() }
}

/** 从档案文件名提取章号：第01章_档案.md -> 1 */
export function archiveChapterIndex(filename: string): number | null {
  const m = filename.match(/第\s*0*(\d+)\s*章/)
  return m ? parseInt(m[1], 10) : null
}

/** 章节统计 */
export function chapterStats(ch: Chapter): ChapterStats {
  const s: ChapterStats = { total: 0, keep: 0, del: 0, revise: 0, totalChars: 0, deletedChars: 0 }
  for (const b of ch.blocks) {
    s.total++
    s.totalChars += b.content.length
    if (b.mark === 'keep') s.keep++
    else if (b.mark === 'delete') { s.del++; s.deletedChars += b.content.length }
    else s.revise++
  }
  return s
}

/** 导出修订版 markdown */
export function exportRevised(project: Project): string {
  const out: string[] = [`# ${project.bookTitle}`, '']
  if (project.bookIntro) out.push(`> ${project.bookIntro}`, '')
  for (const ch of project.chapters) {
    const kept = ch.blocks.filter((b) => b.mark !== 'delete')
    if (kept.length === 0) continue
    out.push(`## ${ch.title}`, '')
    for (const b of kept) {
      if (b.speaker !== '叙述') out.push(`**${b.speaker}**`, '')
      if (b.mark === 'revise') out.push('> ⚠️ 待修', '')
      out.push(b.content, '')
    }
  }
  return out.join('\n')
}

/** 导出编辑方案 JSON（含原文，可再导入恢复） */
export function exportProjectJson(project: Project): string {
  return JSON.stringify({ ...project, updatedAt: Date.now() }, null, 2)
}

/** 导入编辑方案 JSON */
export function importProjectJson(json: string): Project | null {
  try {
    const p = JSON.parse(json)
    if (!p || !Array.isArray(p.chapters)) return null
    return p as Project
  } catch {
    return null
  }
}

/** 触发浏览器下载 */
export function downloadFile(filename: string, content: string, mime = 'text/plain') {
  const blob = new Blob(['﻿' + content], { type: `${mime};charset=utf-8` })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
