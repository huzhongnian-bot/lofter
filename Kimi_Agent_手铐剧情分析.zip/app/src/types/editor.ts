export type MarkType = 'keep' | 'delete' | 'revise'

export interface Block {
  id: string
  speaker: string // '凯·默瑟' | '裘德' | '叙述'
  content: string
  mark: MarkType
  note: string
}

export interface Chapter {
  id: string
  index: number // 章号
  title: string
  blocks: Block[]
}

export interface Project {
  bookTitle: string
  bookIntro: string
  chapters: Chapter[]
  archives: Record<string, string> // chapterId -> 档案 markdown
  updatedAt: number
}

export interface ChapterStats {
  total: number
  keep: number
  del: number
  revise: number
  totalChars: number
  deletedChars: number
}
